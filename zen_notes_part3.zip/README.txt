Zen Notes — Part 1 (skeleton)
Files:
- lib/main.dart : main app code (editor, list, sqlite)
- pubspec.yaml : dependencies

Instructions (brief):
1. Install Flutter SDK.
2. Run `flutter pub get`.
3. Run `flutter run` (you may need to run `flutter create .` once to generate platform folders).

This is the first iteration skeleton — upload back when you want the next edits.
